function [projectroot] = csa_git_projectroot


currdir     = mfilename('fullpath');

% check which system is running from - window or linux platforms
syscheck = findstr(currdir,'\');

% Identify the root depending on system type
% ------------------------------------------
if isempty(syscheck) 
    strdirs     = strsplit(currdir,'/'); % Linux system
else
    strdirs     = strsplit(currdir,'\'); % Windows system
end

% Get project root directory
% --------------------------
idx         = find(strcmp(strdirs,'projects'));
projectroot = fullfile(strdirs{1:idx});

if isempty(syscheck) 
    projectroot = ['/' projectroot];
end

