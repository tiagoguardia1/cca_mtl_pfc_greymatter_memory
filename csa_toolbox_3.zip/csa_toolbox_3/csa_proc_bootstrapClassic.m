function [cfgOut] = myplsbootstr(x,y,lambdaX,lambdaY,numComp)
    % select out the coefficients that are to be bootstrapped.

    opt         = [];
    opt.lambdaX = lambdaX;%1;
    opt.lambdaY = lambdaY;%opt.lambdaX;
    opt.doCovs  = 0;
    opt.numComp = numComp;%min([size(x) size(y)]);
    
    CSA = csa_proc_CCA(opt,x,y);
    
    cfgOut.R    = CSA.R;
    cfgOut.P    = CSA.P;
    cfgOut.Cov  = CSA.Cov;
    cfgOut.XL   = CSA.XL;
    cfgOut.YL   = CSA.YL;
    cfgOut.XS   = CSA.XS;    
    cfgOut.YS   = CSA.YS;
    cfgOut.XW   = CSA.XW;
    cfgOut.YW   = CSA.YW;
    
end
