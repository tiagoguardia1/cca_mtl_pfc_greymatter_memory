function isdefault= csa_setDefault(opt,tag,value)
  stridx= strfind(tag,'.'); % check whether a substruct is referenced
  if ~isempty(stridx)
      tagstart= ['.' tag(1:stridx(end)-1)];
      tagend= tag(stridx(end)+1:end);
  else
      tagstart= [];
      tagend= tag;
  end
  if ~eval(['isfield(opt' tagstart ',''' tagend ''')'])
    eval(['opt.' tag '=value;'])
    % Transfer new value to calling function
    assignin('caller','opt',opt);    
    isdefault= 1;
  else
    isdefault= 0;
  end
end