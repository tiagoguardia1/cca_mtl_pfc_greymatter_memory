function p = csa_stats_chi2pval(x,v)
%   FPVAL Chi-square distribution p-value function.
%   P = CHI2PVAL(X,V) returns the upper tail of the chi-square cumulative
%   distribution function with V degrees of freedom at the values in X.  If X
%   is the observed value of a chi-square test statistic, then P is its
%   p-value.
%
%   The size of P is the common size of the input arguments.  A scalar input  
%   functions as a constant matrix of the same size as the other inputs.    
%
%   See also CHI2CDF, CHI2INV.

%   References:
%      [1]  M. Abramowitz and I. A. Stegun, "Handbook of Mathematical
%      Functions", Government Printing Office, 1964, 26.4.

%   Copyright 2009 The MathWorks, Inc. 
%   
%   Edit Log
%   ----------
%   07/03/2018 - Cannibalized from canoncorr function
%   08/03/2018 - added other funcitons as sub-functions 

if nargin < 2
    error(message('stats:chi2pval:TooFewInputs'));
end

[errorcode,x,v] = distchck(2,x,v);

if errorcode > 0
    error(message('stats:chi2pval:InputSizeMismatch'));
end

% Return NaN for out of range parameters.
v(v <= 0) = NaN;
x(x < 0) = 0;

p = gammainc(x/2,v/2,'upper');


function [errorcode,varargout] = distchck(nparms,varargin)
%DISTCHCK Checks the argument list for the probability functions.

%   Copyright 1993-2014 The MathWorks, Inc. 


errorcode = 0;
varargout = varargin;

if nparms == 1
    return;
end

% Get size of each input, check for scalars, copy to output
scalar = cellfun( @isscalar, varargin );

% Done if all inputs are scalars.  Otherwise fetch their common size.
if (all(scalar)), return; end

n = nparms;

sz = cellfun( @size, varargin, 'UniformOutput', false );
t = sz(~scalar);
size1 = t{1};

% Scalars receive this size.  Other arrays must have the proper size.
for j=1:n
   sizej = sz{j};
   if (scalar(j))
      vj = varargin{j};
      if isnumeric(vj)
         t = zeros(size1,'like',vj);
      else
         t = zeros(size1);
      end
      t(:) = vj;
      varargout{j} = t;
   elseif (~isequal(sizej,size1))
      errorcode = 1;
      return;
   end
end


%GAMMAINC Incomplete gamma function.
%   Y = GAMMAINC(X,A) evaluates the incomplete gamma function for
%   corresponding elements of X and A.  The elements of A must be nonnegative.
%   X and A must be real and the same size (or either can be a scalar).
%
%   The incomplete gamma function is defined as:
%
%    gammainc(x,a) = 1 ./ gamma(a) .*
%       integral from 0 to x of t^(a-1) exp(-t) dt
%
%   For any a>=0, as x approaches infinity, gammainc(x,a) approaches 1. For
%   small x and a, gammainc(x,a) ~ x^a, so gammainc(0,0) = 1.
%
%   Y = GAMMAINC(X,A,TAIL) specifies the tail of the incomplete gamma function
%   when X is non-negative.  Choices are 'lower' (the default) to compute the
%   integral from 0 to X, or 'upper' to compute the integral from X to
%   infinity.  These two choices are related as
%
%      GAMMAINC(X,A,'upper') = 1 - GAMMAINC(X,A,'lower').
%
%   When the upper tail value is close to 0, the 'upper' option provides a way
%   to compute that value more accurately than by subtracting the lower tail
%   value from 1.
%
%   Warning: When X is negative, Y can be inaccurate for abs(X) > A+1.
%
%   Y = GAMMAINC(X,A,'scaledlower') and GAMMAINC(X,A,'scaledupper') return
%   the incomplete gamma function, scaled by GAMMA(A+1)*EXP(X)/X^A.  These
%   functions are unbounded above, but are useful for values of X and A where
%   GAMMAINC(X,A,'lower') or GAMMAINC(X,A,'upper') underflow to zero.
%
%   Class support for inputs X,A:
%      float: double, single
%
%   See also GAMMAINCINV, GAMMA, GAMMALN, PSI.

%   References:
%      [1] Abramowitz & Stegun, Handbook of Mathematical Functions,
%          Sec. 6.5, especially 6.5.29 and 26.5.31.
%      [2] Knuesel, L. (1986) "Computation of the Chi-square and Poisson
%          Distribution", SIAM J. Sci. Stat. Comput., 7(3):1022-1036.

%   Copyright 1984-2014 The MathWorks, Inc.

