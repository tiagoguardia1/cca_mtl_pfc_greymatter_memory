function [CSAout] = csa_stats_rCVA_bootstrClassic(CVA)
% Classic Bootstrapping PLS
% see Efron and Tibshiirani, 1986, https://www.jstor.org/stable/2245500?seq=1 
% see Misic et al 2016, https://www.jneurosci.org/content/36/2/419




cfg = CVA.mode.bootClassic;

% -------------------------------------------------------------------------
% Unpack CVA
numPerm             = cfg.numPerm;
numBoot             = cfg.numBoot;
% labels              = cfg.labels; % Not implemented, if at all needed
Xorig               = CVA.X;% Need this for the permutations
Yorig               = CVA.Y;
Ns                  = CVA.Ns;
lambdaX             = CVA.lambdaX;
lambdaY             = CVA.lambdaY;
numComp             = CVA.numComp;
doCovs              = CVA.doCovs;
numVarX             = CVA.numVarX;
numVarY             = CVA.numVarY;
nsub                = CVA.Ns;
dirOut              = CVA.dirOutNulls;
doSaveNulls         = CVA.doSaveNulls;
presetRandOrder     = CVA.randOrder;
usePresetRandOrder  = CVA.usePresetRandOrder;


%-Get parameters for the entire dataset
%--------------------------------------
opt         = [];
opt.lambdaX = lambdaX;
opt.lambdaY = lambdaY;
opt.doCovs  = doCovs;
opt.numComp = min([size(Xorig) size(Yorig)]);
CSAreal     = csa_proc_CCA(opt,Xorig,Yorig);

%-Get parameters for bootstraps
%------------------------------
Breal = csa_stats_rCVA_bootstrClassic_innerloop(CVA);



% -------------------------------------
% Extract parameters for each bootstrap
% -------------------------------------
Rreal = Breal.R;
Preal = Breal.P;
Creal = Breal.Cov;
XLbsr = Breal.XLbsr;
YLbsr = Breal.YLbsr;
XWbsr = Breal.XWbsr;
YWbsr = Breal.YWbsr;


%-Predefine some variables
%--------------------------
Rnull  = nan(numComp,numPerm);
Pnull  = nan(numComp,numPerm);
Cnull  = nan(numComp,numPerm);

% XLnullPval = nan(numPerm,nvarX);
% XLnullHval = nan(numPerm,nvarX);
% XLnullZval = nan(numPerm,nvarX);
% YLnullPval = nan(numPerm,nvarY);
% YLnullHval = nan(numPerm,nvarY);
% YLnullZval = nan(numPerm,nvarY);
XLbsrnull  = nan(numVarX,numComp,numPerm);
XWbsrnull  = nan(numVarX,numComp,numPerm);
YLbsrnull  = nan(numVarY,numComp,numPerm);
YWbsrnull  = nan(numVarY,numComp,numPerm);


parfor iperm = 1:numPerm
    
    tempOrder = randperm(nsub);
    Ytemp     = Yorig(tempOrder,:);
    
    cvanull     = CVA;
    cvanull.Y   = Ytemp;
    Bnull       = csa_stats_rCVA_bootstrClassic_innerloop(cvanull);

    % -------------------------------------
    % Extract parameters for each permutation
    % -------------------------------------
    Rnull(:,iperm) = Bnull.R;
    Pnull(:,iperm) = Bnull.P;
    Cnull(:,iperm) = Bnull.Cov;
    
    XLbsrnull(:,:,iperm) = Bnull.XLbsr;
    YLbsrnull(:,:,iperm) = Bnull.YLbsr;
    XWbsrnull(:,:,iperm) = Bnull.XWbsr;
    YWbsrnull(:,:,iperm) = Bnull.YWbsr;
end


% ------------------------------------------------------------
% Determine significance based on permutations
% ------------------------------------------------------------
pPermXL = sum(XLbsrnull > repmat(XLbsr,1,1,numPerm),3)/numPerm;
pPermYL = sum(YLbsrnull > repmat(YLbsr,1,1,numPerm),3)/numPerm;
pPermXW = sum(XWbsrnull > repmat(XWbsr,1,1,numPerm),3)/numPerm;
pPermYW = sum(YWbsrnull > repmat(YWbsr,1,1,numPerm),3)/numPerm;
pPermR  = sum(Rnull>repmat(Rreal,1,numPerm),2)/numPerm;
pPermP  = sum(Pnull<repmat(Preal,1,numPerm),2)/numPerm;
pPermC  = sum(Cnull>repmat(Creal,1,numPerm),2)/numPerm;


%-Assemble output structure
%--------------------------
CSAout          = CVA;
CSAout.XL       = CSAreal.XL;
CSAout.YL       = CSAreal.YL;
CSAout.XW       = CSAreal.XW;
CSAout.YW       = CSAreal.YW;
CSAout.XS       = CSAreal.XS;
CSAout.YS       = CSAreal.YS;
CSAout.pPermXL  = pPermXL;
CSAout.pPermYL  = pPermYL;
CSAout.pPermXW  = pPermXW;
CSAout.pPermYW  = pPermYW;
CSAout.R        = CSAreal.R';
CSAout.Cov      = CSAreal.Cov';
CSAout.P        = CSAreal.P';
CSAout.pPermR   = pPermR';
CSAout.pPermP   = pPermP';
CSAout.pPermCov = pPermC';
