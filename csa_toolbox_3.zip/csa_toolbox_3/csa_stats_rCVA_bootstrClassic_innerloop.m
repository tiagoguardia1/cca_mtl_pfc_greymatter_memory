function [CVAout] = csa_stats_rCVA_bootstrClassic_innerloop(CVA)
% Function for Inner Bootstrapping 

% ----------------------------
% Unpack cfg structure
% -------------------------------------------------------------------------
% Unpack CVA
cfg                 = CVA.mode.bootClassic;
numPerm             = cfg.numPerm;
numBoot             = cfg.numBoot;
% labels              = cfg.labels; % Not implemented, if at all needed
Xorig               = CVA.X;% Need this for the permutations
Yorig               = CVA.Y;
Ns                  = CVA.Ns;
lambdaX             = CVA.lambdaX;
lambdaY             = CVA.lambdaY;
numComp             = CVA.numComp;
doCovs              = CVA.doCovs;
numVarX             = CVA.numVarX;
numVarY             = CVA.numVarY;
nsub                = CVA.Ns;
dirOut              = CVA.dirOutNulls;
doSaveNulls         = CVA.doSaveNulls;
presetRandOrder     = CVA.randOrder;
usePresetRandOrder  = CVA.usePresetRandOrder;


% Currently only for PLS
opt         = [];
opt.lambdaX = lambdaX;
opt.lambdaY = lambdaY;
opt.doCovs  = doCovs;
opt.numComp = min([size(Xorig) size(Yorig)]);
CSA         = csa_proc_CCA(opt,Xorig,Yorig);

Boot   = bootstrp(numBoot, @csa_proc_bootstrapClassic,Xorig,Yorig,lambdaX,lambdaY,numComp); %

% -------------------------------------
% Extract parameters for each bootstrap
% -------------------------------------
R = median([Boot.R],2);
P = median([Boot.P],2);
C = median([Boot.Cov],2);
XL    = reshape([Boot.XL],numVarX,numComp,numBoot);
YL    = reshape([Boot.YL],numVarY,numComp,numBoot);
XW    = reshape([Boot.XW],numVarX,numComp,numBoot);
YW    = reshape([Boot.YW],numVarY,numComp,numBoot);
XS    = reshape([Boot.XS],nsub,numComp,numBoot);
YS    = reshape([Boot.YS],nsub,numComp,numBoot);


% ---------------------------------------------------------------------------------------
% There can be sign-flips across the bootstraps, correct for that (taking boot 1 as reference)
% ---------------------------------------------------------------------------------------
% warning('---- There can be sign-flips across the folds, correct for that (taking fold 1 as reference)\n');
for nn=2:numBoot
    for comp=1:numComp
        %%% check if scalar product of loadings is negative
        if  (XL(:,comp,1)' * XL(:,comp,nn) < 0)
            
            XL(:,comp,nn)  = -XL(:,comp,nn);
            YL(:,comp,nn)  = -YL(:,comp,nn);
            XW(:,comp,nn)  = -XW(:,comp,nn);
            YW(:,comp,nn)  = -YW(:,comp,nn);
            XS(:,comp,nn)  = -XS(:,comp,nn);
            YS(:,comp,nn)  = -YS(:,comp,nn);
%                 Output.VERBOSE('X+Y sign flip in fold=%d, comp=%d\n',nn,comp)
%             fprintf('X+Y sign flip in fold=%d, comp=%d\n',nn,comp);
        end
    end
end

% Summary estimates across bootstraps
XLmed = median(XL,3);
YLmed = median(YL,3);
XLse  = std(XL,0,3)./sqrt(size(XL,1));
YLse  = std(YL,0,3)./sqrt(size(YL,1));

XWmed = median(XW,3);
YWmed = median(YW,3);
XWse  = std(XW,0,3)./sqrt(size(XW,1));
YWse  = std(YW,0,3)./sqrt(size(YW,1));

% -------------------------------
% Calculate Bootstrap ratios
% -------------------------------
XLbsr = abs(CSA.XL./XLse);
YLbsr = abs(CSA.YL./YLse);
XWbsr = abs(CSA.XW./XWse);
YWbsr = abs(CSA.YW./YWse);


% -----------------------------------------------------
% Flip negative loadings (based on median) to positive
XLnosign = XL .* repmat(sign(XLmed),1,1,numBoot);
YLnosign = YL .* repmat(sign(YLmed),1,1,numBoot);


% YLnull = zeros(numVarY,numComp);
% XLnull = zeros(numVarX,numComp);
% Rnull  = nan(numComp,numPerm);

% XLnullPval = nan(numPerm,nvarX);
% XLnullHval = nan(numPerm,nvarX);
% XLnullZval = nan(numPerm,nvarX);
% YLnullPval = nan(numPerm,nvarY);
% YLnullHval = nan(numPerm,nvarY);
% YLnullZval = nan(numPerm,nvarY);
% XLbsrnull  = nan(numVarX,numComp,numPerm);
% XWbsrnull  = nan(numVarX,numComp,numPerm);
% YLbsrnull  = nan(numVarY,numComp,numPerm);
% YWbsrnull  = nan(numVarY,numComp,numPerm);

%-Assemble output structure
%--------------------------

CVAout.R        = R;
CVAout.P        = P;
CVAout.Cov      = C;
CVAout.XLbsr    = XLbsr;
CVAout.YLbsr    = YLbsr;
CVAout.XWbsr    = XWbsr;
CVAout.YWbsr    = YWbsr;
CVAout.XLnosign = XLnosign;
CVAout.YLnosign = YLnosign;

