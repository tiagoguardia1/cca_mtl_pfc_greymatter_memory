function kat_parfor_save(filename,varnames,varargin)
% Save data in parfor loop. 
%
% kat_parfor_save(FILENAME,VARNAMES, VAR1, VAR2, ..., <SAVEOPT>)
% Input:
% filename  - string with the filename
% varnames  - cell array with variable names
% var1, ... - variables to be saved
% saveopt   - string (e.g. '-v7.3') passed to the Matlab save function).
%             Default []
%
%
    
if ischar(varargin{end}) && strcmp('-',varargin{end}(1))
    nVars= nargin-3;
    saveopt= varargin{end};
else
    nVars= nargin-2;
    saveopt= [];
end

% Assign data to variable names
for ii = 1:nVars
    eval([varnames{ii} '= varargin{ii};']);
end

if isempty(saveopt)
    save(filename,varnames{:});
else
    save(filename,varnames{:},saveopt);
end
